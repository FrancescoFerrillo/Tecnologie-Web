document.addEventListener("DOMContentLoaded", function () {
    const container = document.getElementById("animated-container");
    container.classList.add("show"); 
});
